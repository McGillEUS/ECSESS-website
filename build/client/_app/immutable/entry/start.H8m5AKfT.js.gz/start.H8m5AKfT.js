import{l as o,a as r}from"../chunks/C9pg3DAp.js";export{o as load_css,r as start};
